<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="props" tilewidth="64" tileheight="62" tilecount="11" columns="0" objectalignment="bottomleft">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0" type="prop">
  <properties>
   <property name="prop" value="bamboo"/>
   <property name="anchorX" type="float" value="10"/>
   <property name="anchorY" type="float" value="47"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="tall"/>
  </properties>
  <image source="images/bamboo.png" width="20" height="50"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="6" y="43" width="8" height="4">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1" type="prop">
  <properties>
   <property name="prop" value="blossom_tree"/>
   <property name="anchorX" type="float" value="12"/>
   <property name="anchorY" type="float" value="33"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="tall"/>
  </properties>
  <image source="images/blossom_tree.png" width="24" height="34"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="8.5" y="29" width="7" height="4">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="2" type="prop">
  <properties>
   <property name="prop" value="bridge"/>
   <property name="anchorX" type="float" value="32"/>
   <property name="anchorY" type="float" value="25"/>
   <property name="solid" type="bool" value="false"/>
   <property name="occlusionClass" value="low"/>
  </properties>
  <image source="images/bridge.png" width="64" height="26"/>
 </tile>
 <tile id="3" type="prop">
  <properties>
   <property name="prop" value="hall"/>
   <property name="anchorX" type="float" value="32"/>
   <property name="anchorY" type="float" value="47"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="tall"/>
  </properties>
  <image source="images/hall.png" width="64" height="48"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="19" y="33" width="26" height="14"/>
  </objectgroup>
 </tile>
 <tile id="4" type="prop">
  <properties>
   <property name="prop" value="lantern"/>
   <property name="anchorX" type="float" value="8"/>
   <property name="anchorY" type="float" value="29"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="low"/>
  </properties>
  <image source="images/lantern.png" width="16" height="32"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="5.5" y="25" width="5" height="4">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="5" type="prop">
  <properties>
   <property name="prop" value="pagoda"/>
   <property name="anchorX" type="float" value="24"/>
   <property name="anchorY" type="float" value="61"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="tall"/>
  </properties>
  <image source="images/pagoda.png" width="48" height="62"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="15" y="49" width="18" height="12"/>
  </objectgroup>
 </tile>
 <tile id="6" type="prop">
  <properties>
   <property name="prop" value="rock"/>
   <property name="anchorX" type="float" value="9"/>
   <property name="anchorY" type="float" value="11"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="low"/>
  </properties>
  <image source="images/rock.png" width="18" height="14"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="2.5" y="6" width="13" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="7" type="prop">
  <properties>
   <property name="prop" value="sect_gate"/>
   <property name="anchorX" type="float" value="28"/>
   <property name="anchorY" type="float" value="45"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="tall"/>
  </properties>
  <image source="images/sect_gate.png" width="56" height="46"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="21" y="37" width="14" height="8"/>
  </objectgroup>
 </tile>
 <tile id="8" type="prop">
  <properties>
   <property name="prop" value="shrub"/>
   <property name="anchorX" type="float" value="10"/>
   <property name="anchorY" type="float" value="12"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="low"/>
  </properties>
  <image source="images/shrub.png" width="20" height="15"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="3" y="7" width="14" height="5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="9" type="prop">
  <properties>
   <property name="prop" value="signboard"/>
   <property name="anchorX" type="float" value="12"/>
   <property name="anchorY" type="float" value="25"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="low"/>
  </properties>
  <image source="images/signboard.png" width="24" height="28"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="9" y="20" width="6" height="5"/>
  </objectgroup>
 </tile>
 <tile id="10" type="prop">
  <properties>
   <property name="prop" value="teahouse"/>
   <property name="anchorX" type="float" value="24"/>
   <property name="anchorY" type="float" value="39"/>
   <property name="solid" type="bool" value="true"/>
   <property name="occlusionClass" value="tall"/>
  </properties>
  <image source="images/teahouse.png" width="48" height="40"/>
  <objectgroup draworder="index" id="2">
   <object id="1" name="footprint" type="footprint" x="13" y="27" width="22" height="12"/>
  </objectgroup>
 </tile>
</tileset>
