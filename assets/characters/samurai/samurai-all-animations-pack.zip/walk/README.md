# Samurai — caminhada top-down em 8 direções (corrigida)

A grade tem **4 colunas × 8 linhas**, com cada célula em **64 × 64 px** e transparência RGBA. Há quatro fases por direção (32 quadros PNG) e uma prévia GIF por direção.

A ordem das linhas, de cima para baixo, é: **cima (N), cima-direita (NE), direita (E), baixo-direita (SE), baixo (S), baixo-esquerda (SW), esquerda (W), cima-esquerda (NW)**. Cada grupo direcional foi gerado separadamente e reunido nessa ordem para evitar a mistura anterior.

O QC estrito da exportação passou: sem quadros vazios, recortes, clamp ou toque de borda. A grade final mede **256 × 512 px**.
