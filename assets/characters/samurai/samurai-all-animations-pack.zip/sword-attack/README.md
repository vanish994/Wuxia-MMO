# Samurai — ataque com espada em 8 direções

## Atlas

- **Arquivo:** `samurai-attack-8dir-64px.png`
- **Formato:** PNG RGBA com transparência
- **Grade:** 4 colunas × 8 linhas; cada célula mede 64×64 px (atlas total: 256×512 px)
- **Animação:** 4 quadros por direção, na ordem da esquerda para a direita
- **Prévia GIF:** 200 ms por quadro (5 quadros/s), em loop

## Ordem das linhas

| Linha | Direção | Nome usado nos arquivos |
|---:|---|---|
| 1 | Norte | `up` |
| 2 | Nordeste | `up-right` |
| 3 | Leste | `right` |
| 4 | Sudeste | `down-right` |
| 5 | Sul | `down` |
| 6 | Sudoeste | `down-left` |
| 7 | Oeste | `left` |
| 8 | Noroeste | `up-left` |

`frames/` contém os 32 quadros PNG individuais; `animations/` contém um GIF por direção; `strips/` contém uma tira horizontal de quatro quadros por direção. Os metadados completos e um resumo do QA estão em `metadata/`.

## Validação

O pipeline de sprites passou no **QC estrito**: 32/32 quadros válidos, nenhum quadro vazio, nenhum sprite encostando na borda final e nenhum quadro recortado/clampado. O atlas e os quadros individuais foram verificados como RGBA transparente nas dimensões especificadas.
