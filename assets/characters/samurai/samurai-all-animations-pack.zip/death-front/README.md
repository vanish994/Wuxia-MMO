# Samurai — animação de morte frontal

A animação contém quatro quadros de 64×64 px, em uma tira horizontal 1×4: **cambaleio → ajoelha → cai de costas → permanece imóvel**. O último quadro é a pose final, com os olhos fechados.

- `samurai-death-front-64px.png`: tira RGBA 256×64, com transparência real.
- `frames/`: quatro PNGs individuais, numerados na ordem de reprodução.
- `samurai-death-front.gif`: prévia de execução única; os quadros duram 180, 180, 240 e 1200 ms, respectivamente, para segurar a pose final.
- `metadata/`: prompt, procedência e resumo do QC. `metadata/pipeline/` guarda a saída completa do processador.

O processamento final passou no QC estrito: quatro quadros exportados, sem quadros vazios, recortados ou encostando à borda de saída. Os PNGs são a fonte recomendada para integração no jogo; o GIF é apenas uma prévia.
