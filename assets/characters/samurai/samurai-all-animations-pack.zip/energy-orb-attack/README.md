# Samurai — ataque com orbes de energia azul em 8 direções

## Atlas

- **Arquivo:** `samurai-energy-orb-8dir-64px.png`
- **Formato:** PNG RGBA com transparência real; os orbes têm pixels de alfa parcial
- **Grade:** 4 colunas × 8 linhas; cada quadro mede 64×64 px (atlas total: 256×512 px)
- **Animação:** 4 quadros por direção, lidos da esquerda para a direita
- **Prévia GIF:** 200 ms por quadro (5 quadros/s), em loop

## Ordem das linhas

| Linha | Direção | Nome nos arquivos |
|---:|---|---|
| 1 | Norte | `up` |
| 2 | Nordeste | `up-right` |
| 3 | Leste | `right` |
| 4 | Sudeste | `down-right` |
| 5 | Sul | `down` |
| 6 | Sudoeste | `down-left` |
| 7 | Oeste | `left` |
| 8 | Noroeste | `up-left` |

O ciclo segue as fases de preparação, formação/carga do orbe, disparo e recuperação. `frames/` contém 32 PNGs individuais; `animations/` contém um GIF por direção; `strips/` contém tiras horizontais de quatro quadros. Os metadados e o resumo de QA estão em `metadata/`.

## Validação

O pipeline passou no **QC estrito**: 32/32 quadros válidos, nenhum vazio, nenhum encostando na borda final e nenhum quadro recortado/clampado. As esferas mantêm transparência parcial e o fundo dos sprites permanece transparente.
