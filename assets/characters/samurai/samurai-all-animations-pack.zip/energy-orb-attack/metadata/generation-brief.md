# Briefing de geração — orbes de energia

- **Objetivo:** ciclo de ataque do mesmo samurai em oito direções.
- **Referências:** imagem original do personagem para identidade e paleta; folha de ataque anterior correspondente à direção para pose e orientação.
- **Estilo:** pixel art 16-bit, contorno escuro, cabelo preto preso, roupa azul-marinho com padrão branco, faixa vermelha, sandálias/tabi; katana embainhada nas costas.
- **Efeito:** esfera de energia azul/ciano com centro semitransparente, aro luminoso e brilho contido; as partículas ficam dentro do quadro.
- **Fases por folha 2×2:** preparação, carga/formação, disparo, recuperação.
- **Direção:** cada imagem foi gerada separadamente com rumo e vista definidos; sem rótulos ou linhas de grade.
- **Geração de imagem:** ferramenta `generate_image`; modelo solicitado `gpt-image-2.5`; proporção 1:1; fundo transparente nativo habilitado. O recibo de geração não informou uma rota alternativa nem um modelo retornado distinto.
- **Pós-processamento:** montagem por posse de componentes; exportação em RGBA 64×64 por célula com escala compartilhada e QC estrito.
