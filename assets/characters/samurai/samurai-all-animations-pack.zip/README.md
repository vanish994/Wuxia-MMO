# Samurai — pacote completo de animações

Este pacote reúne os assets finais do personagem: caminhada, idle respirando, ataque com espada, ataque com orbe de energia azul e morte frontal. Cada pasta mantém os arquivos e metadados JSON do respectivo pacote de origem e inclui um `animation.json` padronizado. O `manifest.json` na raiz indexa as ações e os atlas.

| Ação | Direções | Quadros | Reprodução |
|---|---|---:|---|
| `walk/` | 8 | 4 por direção | loop |
| `idle/` | 8 | 4 por direção | loop |
| `sword-attack/` | 8 | 4 por direção | loop da prévia GIF |
| `energy-orb-attack/` | 8 | 4 por direção | loop da prévia GIF |
| `death-front/` | frontal / sul | 4 | uma vez; mantém a pose final |

Para os atlas de oito direções, as linhas seguem a ordem: **cima, cima-direita, direita, baixo-direita, baixo, baixo-esquerda, esquerda, cima-esquerda**. Cada célula mede 64×64 px; os atlas são RGBA de 256×512 px. A morte é uma tira RGBA frontal de 256×64 px.

Os GIFs são prévias. Para integração no jogo, use os PNGs RGBA e o JSON da ação correspondente. As prévias dos ataques foram exportadas em loop; a configuração real de repetição e o disparo da ação devem ser controlados pelo jogo.
