# Samurai — idle em 8 direções

Atlas transparente **RGBA de 256×512 px**, com células de **64×64 px**. Cada linha contém quatro quadros de respiração sutil, lidos da esquerda para a direita; as oito animações são cíclicas e os GIFs de prévia usam 200 ms por quadro (5 fps).

| Linha | Direção |
|---:|---|
| 1 | Cima (norte) |
| 2 | Cima-direita (nordeste) |
| 3 | Direita (leste) |
| 4 | Baixo-direita (sudeste) |
| 5 | Baixo (sul) |
| 6 | Baixo-esquerda (sudoeste) |
| 7 | Esquerda (oeste) |
| 8 | Cima-esquerda (noroeste) |

O pacote inclui a folha completa, 32 PNGs individuais, tiras e GIFs por direção, prévia estática em fundo claro e metadados do processador. Use os PNGs RGBA no jogo; GIFs são apenas prévias.

**Validação:** 32/32 quadros exportados em 64×64, folha final RGBA 256×512, QC estrito aprovado. O processamento usou escala compartilhada e limites explícitos de variação de escala corporal (0,08) e alinhamento vertical (0,05). A geração foi feita com `manus-tools.generate_image`; o recibo não informou a rota/modelo efetivos.
