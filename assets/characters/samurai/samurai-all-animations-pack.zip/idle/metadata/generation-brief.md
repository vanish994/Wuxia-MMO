# Briefing do idle em 8 direções

**Personagem:** mesmo samurai da referência original — cabelo preto preso, roupa azul-marinho, manga branca estampada, faixa vermelha, tabi brancas e katana embainhada. A referência direcional usada em cada geração orienta somente a câmera e o rumo; a esfera azul e a pose de ataque foram excluídas.

**Grade por direção:** 2×2, quatro poses em ordem de leitura: neutro, inspiração leve, pico/expiração com cabelo e tecido acompanhando sutilmente, retorno ao neutro. Pés e quadril permanecem plantados; sem caminhada, golpe, magia ou deslocamento. Fundo alfa real.

| Ordem no atlas | Rumo | Vista |
|---|---|---|
| 1 | Norte / cima | Traseira |
| 2 | Nordeste / cima-direita | Traseira em três quartos |
| 3 | Leste / direita | Perfil direito |
| 4 | Sudeste / baixo-direita | Frontal em três quartos |
| 5 | Sul / baixo | Frontal |
| 6 | Sudoeste / baixo-esquerda | Frontal em três quartos |
| 7 | Oeste / esquerda | Perfil esquerdo |
| 8 | Noroeste / cima-esquerda | Traseira em três quartos |

A primeira folha noroeste tinha braços erguidos e foi substituída por uma folha corrigida com os braços relaxados antes da montagem.
